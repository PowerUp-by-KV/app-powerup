import { useCallback } from "react";
import { Platform } from "react-native";
import { useColorScheme } from "nativewind";
import * as SecureStore from "expo-secure-store";

export function useThemeToggle() {
  const { colorScheme, setColorScheme } = useColorScheme();
  const isDark = colorScheme === "dark";

  const toggleTheme = useCallback(() => {
    const nextIsDark = !isDark;
    const nextTheme: "light" | "dark" = nextIsDark ? "dark" : "light";

    // Immediately update NativeWind scheme
    setColorScheme(nextTheme);

    // Immediately update Web DOM class if on web
    if (Platform.OS === "web" && typeof document !== "undefined") {
      if (nextIsDark) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    }

    // Persist setting in background
    try {
      if (Platform.OS === "web" && typeof window !== "undefined") {
        window.localStorage?.setItem("settings_dark_mode", String(nextIsDark));
      } else if (Platform.OS !== "web") {
        SecureStore.setItemAsync("settings_dark_mode", String(nextIsDark)).catch((err) => {
          console.warn("Failed to save dark mode setting", err);
        });
      }
    } catch (err) {
      console.warn("Failed to save dark mode setting", err);
    }
  }, [isDark, setColorScheme]);

  return { isDark, toggleTheme };
}
