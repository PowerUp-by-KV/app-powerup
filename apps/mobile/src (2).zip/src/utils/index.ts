// Export utility functions here
